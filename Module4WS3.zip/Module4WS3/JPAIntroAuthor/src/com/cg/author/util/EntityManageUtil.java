package com.cg.author.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.cg.author.exception.AuthorException;

public class EntityManageUtil {
	private EntityManagerFactory factory;
	
	public EntityManageUtil() throws AuthorException{
		try{
			factory = Persistence.createEntityManagerFactory("JPA-PU");
		}catch(PersistenceException e){
			throw new AuthorException("Creation failed: Persistent Unit",e);
		}
	}
	
	public EntityManager getManager(){
		return factory.createEntityManager();
	}
	
	public void closeFactory(){
		if(factory!=null){
			factory.close();
		}
	}

	@Override
	protected void finalize() throws Throwable {
		closeFactory();
		super.finalize();
	}
	
	
}
