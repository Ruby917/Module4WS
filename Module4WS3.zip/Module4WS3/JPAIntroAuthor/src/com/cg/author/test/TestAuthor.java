package com.cg.author.test;

import java.util.List;
import java.util.Scanner;

import com.cg.author.dto.Author;
import com.cg.author.exception.AuthorException;
import com.cg.author.service.AuthorServiceImpl;
import com.cg.author.service.IAuthorService;

public class TestAuthor {
	
	public static void main(String[] args) throws AuthorException {
		IAuthorService authservice = new AuthorServiceImpl();
		int choice=0;
		Author a = new Author();
		Scanner sc = new Scanner(System.in);
		do{
			printDetail();
			System.out.println("Enter your Choice: ");
			choice=sc.nextInt();
			switch(choice){
			case 1:
				
				System.out.println("Enter Author Id: ");
				int aId = sc.nextInt();
				
				System.out.println("Enter first name of Author: ");
				String aFname = sc.next();
				
				System.out.println("Enter middle name of Author: ");
				String aMname = sc.next();
				
				System.out.println("Enter last name of Author: ");
				String aLname = sc.next();
				
				System.out.println("Enter Phone number: ");
				long phoneNo = sc.nextLong();
				
				
				
				a.setAuthId(aId);
				a.setAuthFname(aFname);
				a.setAuthMname(aMname);
				a.setAuthLname(aLname);
				a.setPhoneNo(phoneNo);
				
				Author a1 = authservice.addNewAuthor(a);
				System.out.println(a1);
				
				break;
			case 2:
				System.out.println("Author list");
				List<Author> authlist = authservice.displayAuthList();
				for(Author ath:authlist){
					System.out.println(ath);
				}
				break;
			case 3:
				System.out.println("Enter updated Author Id: ");
				int auId = sc.nextInt();

				System.out.println("Enter updated first name of Author: ");
				String auFname = sc.next();

				System.out.println("Enter updated middle name of Author: ");
				String auMname = sc.next();

				System.out.println("Enter updated last name of Author: ");
				String auLname = sc.next();

				System.out.println("Enter updated Phone number: ");
				long auphoneNo = sc.nextLong();

				a.setAuthId(auId);
				a.setAuthFname(auFname);
				a.setAuthMname(auMname);
				a.setAuthLname(auLname);
				a.setPhoneNo(auphoneNo);

				boolean updateStatus = authservice.upadteAuthor(a);
				if(updateStatus==true){
					System.out.println("Author Updated");
				}else{
					System.out.println("Updation Failed");
				}
				break;
			case 4:
				System.out.println("Enter Author Id:");
				int authorId = sc.nextInt();
				boolean deleteStatus = authservice.deleteAuthor(authorId);
				if(deleteStatus==true){
					System.out.println("Author Deleted");
				}else{
					System.out.println("Deletion Failed");
				}
				break;
			case 5:
				System.out.println("Application Exited");
				break;
			
			default:
				System.out.println("Invalid Choice");
			}
		}while(choice!=5);
	}
	private static void printDetail() {
		System.out.println("**********");
		System.out.println("1. Add Author ");
		System.out.println("2. Display Author ");
		System.out.println("3. Update Author ");
		System.out.println("4. Delete Author ");
		System.out.println("5. Exit ");
		System.out.println("***********");
	}

}
