package com.cg.author.service;

import java.util.List;

import com.cg.author.dao.AuthodDaoImpl;
import com.cg.author.dao.IAuthorDao;
import com.cg.author.dto.Author;
import com.cg.author.exception.AuthorException;

public class AuthorServiceImpl implements IAuthorService{

	IAuthorDao authdao = null;
	
	public AuthorServiceImpl() throws AuthorException {
		authdao = new AuthodDaoImpl();
	}

	@Override
	public Author addNewAuthor(Author auth) throws AuthorException {
		return authdao.addNewAuthor(auth);
	}

	@Override
	public List<Author> displayAuthList() throws AuthorException {
		return authdao.displayAuthList();
	}

	@Override
	public boolean upadteAuthor(Author auth) throws AuthorException {
		return authdao.upadteAuthor(auth);
	}

	@Override
	public boolean deleteAuthor(int authId) throws AuthorException {
		return authdao.deleteAuthor(authId);
	}

}
