package com.cg.author.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import com.cg.author.dto.Author;
import com.cg.author.exception.AuthorException;
import com.cg.author.util.EntityManageUtil;

public class AuthodDaoImpl implements IAuthorDao{
	private EntityManageUtil util;
	private EntityManager manager;
	
	public AuthodDaoImpl() throws AuthorException {
		util = new EntityManageUtil();
		manager = util.getManager();
	}

	@Override
	public Author addNewAuthor(Author auth) throws AuthorException {
		try {
			manager.getTransaction().begin();
			manager.persist(auth);
			manager.getTransaction().commit();
		} catch (RollbackException rl) {
			throw new AuthorException("Author duplicated",rl);
		}
		return auth;
	}

	@Override
	public List<Author> displayAuthList() throws AuthorException {
		List<Author> authlist;
		try {
			Query qry = manager.createQuery("Select a from Author a");
			authlist = qry.getResultList();
		} catch (Exception e) {
			throw new AuthorException("Improper query fabrication",e);
		}
		return authlist;
	}

	@Override
	public boolean upadteAuthor(Author auth) throws AuthorException {
		try {
			manager.getTransaction().begin();
			manager.merge(auth);
			System.out.println("************");
			manager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			throw new AuthorException("failed author updation",e);
		}	
		
	}

	@Override
	public boolean deleteAuthor(int authId) throws AuthorException {
		try {
			manager.getTransaction().begin();
			Author a = this.getAuthDetails(authId);
			manager.remove(a);
			System.out.println("************");
			manager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			throw new AuthorException("failed author deletion",e);
		}
	}
	
	private Author getAuthDetails(int authId) throws AuthorException {
		Author auth = manager.find(Author.class, authId);
		if( auth == null){
			throw new AuthorException("wrong  author id");
		}
		return auth;
	}

	@Override
	protected void finalize() throws Throwable {
		util.closeFactory();
		super.finalize();
	}
	
}
