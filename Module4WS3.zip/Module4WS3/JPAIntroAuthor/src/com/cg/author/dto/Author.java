package com.cg.author.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity() // ALIES OF CLASS NAME
@Table(name = "AUTHORS") //TABLE NAME

/*@NamedQueries(
	@NamedQuery(name="getAuthorList", query="select a from AUTHOR a")
)*/
public class Author {
	
	@Id
	@Column(name="AUTHORID")
	private int authId;
	
	@Column(name="FIRSTNAME")
	private String authFname;
	
	@Column(name="MIDDLENAME")
	private String authMname;
	
	@Column(name="LASTNAME")
	private String authLname;

	@Column(name="PHONENO")
	private long phoneNo;
	
	public int getAuthId() {
		return authId;
	}
	public void setAuthId(int authId) {
		this.authId = authId;
	}
	public String getAuthFname() {
		return authFname;
	}
	public void setAuthFname(String authFname) {
		this.authFname = authFname;
	}
	public String getAuthMname() {
		return authMname;
	}
	public void setAuthMname(String authMname) {
		this.authMname = authMname;
	}
	public String getAuthLname() {
		return authLname;
	}
	public void setAuthLname(String authLname) {
		this.authLname = authLname;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	@Override
	public String toString() {
		return "Author [authId=" + authId + ", authFname=" + authFname
				+ ", authMname=" + authMname + ", authLname=" + authLname
				+ ", phoneNo=" + phoneNo + "]";
	}

}
