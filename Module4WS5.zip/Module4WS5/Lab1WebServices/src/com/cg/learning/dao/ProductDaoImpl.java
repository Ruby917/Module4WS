package com.cg.learning.dao;

import java.util.List;

import com.cg.learning.beans.Product;
import com.cg.learning.staticdb.ProductDB;

public class ProductDaoImpl implements IProductDao{
	
	List<Product> productList = ProductDB.loadList();
	

	public ProductDaoImpl() {

	}

	@Override
	public float getProductPrice(String pName) {
		for(Product product : productList){
			if(product.getProdName().equalsIgnoreCase(pName)){
				return product.getProdPrice();
			}
		}
		return -1;
	}

}
