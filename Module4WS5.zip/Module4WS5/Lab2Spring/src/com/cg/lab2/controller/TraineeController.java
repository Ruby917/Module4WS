package com.cg.lab2.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.lab2.dto.Trainee;
import com.cg.lab2.exception.TraineeException;
import com.cg.lab2.service.TraineeService;

@Controller
public class TraineeController {
	private TraineeService trService;

	@Resource(name="traineeService")
	public void settraineeService(TraineeService trService){
		this.trService= trService;
	}
	
	@RequestMapping("login")
	public ModelAndView getLoginPage(){
		ModelAndView model = new ModelAndView("login");
		return model;
	}
	
	@RequestMapping("authenticate")
	public ModelAndView isAuthenticate(@RequestParam("user") String userName,@RequestParam String pwd){
		ModelAndView model = new ModelAndView();
		if(userName.equals("ruby") && pwd.equals("ruby")){
			model.setViewName("operations");
		}else{
			model.addObject("message", "Login Unseccessful. Please Reenter");
			model.setViewName("login");
		}
		return model;
	}
	
	@RequestMapping("operations")
	public ModelAndView getOperationsPage(){
		ModelAndView model = new ModelAndView("operations");
		return model;
	}
	
	@RequestMapping("addTraineeForm")
	public ModelAndView addTraineeForm(){
		ModelAndView model = new ModelAndView("addTraineeForm");
		return model;
	}
	
	@RequestMapping("addTrainee")
	public ModelAndView addTrainee(@RequestParam("trId") String traineeId,@RequestParam("trName") String traineeName,@RequestParam("trLocation") String traineeLocation,@RequestParam("trDomain") String traineeDomain){
		ModelAndView model = null;
		try {
			model = new ModelAndView();
			Trainee tr = new Trainee();
			tr.setTraineeId(Integer.parseInt(traineeId));
			tr.setTraineeName(traineeName);
			tr.setTraineeLocation(traineeLocation);
			tr.setTraineeDomain(traineeDomain);
			Trainee trainee = trService.addTrainee(tr);
			model.setViewName("successInsert");
			model.addObject("trainee", trainee);
		} catch (TraineeException e) {
			model.setViewName("error");
			model.addObject("msg", "Record Insertion Failed:"+e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("deleteTraineeForm")
	public ModelAndView deleteTraineeForm(){
		ModelAndView model = new ModelAndView("deleteTraineeForm");
		return model;
	}
	
	@RequestMapping("deleteTrainee")
	public ModelAndView deleteTrainee(@RequestParam("trNo") int trNo){
		ModelAndView model = null;
		try {
			Boolean status = trService.DeleteTrainee(trNo);
			if(status==true){
				model = new ModelAndView("successDelete");
				model.addObject("traineeId", trNo);
				return model;
			}else{
				model = new ModelAndView("error");
				model.addObject("msg", "Trainee can not be deleted");
				return model;
			}
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("msg", e.getMessage());
			return model;
		}
	}
	
	@RequestMapping("enterTrIdModify")
	public ModelAndView enterTrIdModify(){
		ModelAndView model = new ModelAndView("enterTrIdModify");
		return model;
	}

	@RequestMapping("modifyTraineeForm")
	public ModelAndView modifyTraineeForm(@RequestParam("trNo") int trId){
		ModelAndView model = null;
		try {
			Trainee trainee = trService.getTraineeDetails(trId);
			model = new ModelAndView("modifyTraineeForm");
			model.addObject("trainee", trainee);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("msg", e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("modifyTrainee")
	public ModelAndView modifyTrainee(@ModelAttribute("trainee") @Valid Trainee tr,BindingResult result){
		ModelAndView model = new ModelAndView();
		try {
			Trainee trres = trService.updateTrainee(tr);
			model = new ModelAndView("successModify");
			model.addObject("trainee", trres);
			return model;
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("msg", e.getMessage());
			return model;
		}
	}
	
	@RequestMapping("retrieveTrainee")
	public ModelAndView retrieveTrainee(){
		ModelAndView model = new ModelAndView("enterTraineeNo");
		return model;
	}
	
	@RequestMapping("getTraineeDetails")
	public ModelAndView showTraineeId(@RequestParam int trNo){
		ModelAndView model = null;
		try {
			Trainee trainee = trService.getTraineeDetails(trNo);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails", trainee);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("msg", e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("retrieveAllTrainees")
	public ModelAndView retrieveAllTrainees(){
		ModelAndView model = null;
		try {
			List<Trainee> trainees = trService.getAllTrainee();
			model = new ModelAndView("listAllTrainees");
			model.addObject("trainees", trainees);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("msg", e.getMessage());
		}
		return model;
	}


}
