package com.cg.lab2.dao;

import java.util.List;

import com.cg.lab2.dto.Trainee;
import com.cg.lab2.exception.TraineeException;

public interface TraineeDao {
	Trainee getTraineeDetails(int trId) throws TraineeException;
	List<Trainee> getAllTrainee() throws TraineeException;
	Trainee addTrainee(Trainee tr) throws TraineeException;
	Boolean DeleteTrainee(int trId) throws TraineeException;
	Trainee updateTrainee(Trainee tr) throws TraineeException;
}
