package com.cg.appl.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

//http://localhost:8085/Spring120MvcLogin/login.do
@Controller
public class LoginController {
	
	//Give login.jsp
	@RequestMapping("login")
	public ModelAndView showLoginPage(){
		ModelAndView model = new ModelAndView("login");
		return model;
	}
	
	//do authentication
	/*@RequestMapping("authenticate")
	public ModelAndView authenticate(HttpServletRequest req,HttpServletResponse resp){
		System.out.println(req.getParameter("username"));
		System.out.println(req.getParameter("pwd"));
		ModelAndView model = new ModelAndView("success");
		return model;
	}*/
	
	@RequestMapping("authenticate")
	public ModelAndView authenticate(@RequestParam("username") String userName,@RequestParam String pwd){
		System.out.println(userName);
		System.out.println(pwd);
		ModelAndView model = new ModelAndView();
		if(userName.equals("a") && pwd.equals("a")){
			model.setViewName("success");
			model.addObject("username", userName);
		}else{
			model.addObject("message", "Login Unseccessful. Please Reenter");
			model.setViewName("login");
		}
		
		return model;
	}
	
	//show main menu or show login page again
	
	

}
