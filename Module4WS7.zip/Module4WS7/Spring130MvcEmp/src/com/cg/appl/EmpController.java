package com.cg.appl;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


//http://localhost:8085/Spring130MvcEmp/welcome.do
@Controller
public class EmpController {
	
	@RequestMapping("welcome")
	public ModelAndView welcomePage(){
		ModelAndView model = new ModelAndView("welcome");
		return model;
	}
	
	@RequestMapping("emp")
	public ModelAndView getEmpId(){
		ModelAndView model = new ModelAndView("emp");
		return model;
	}
	
	@RequestMapping("show")
	public ModelAndView showEmpId(@RequestParam("empid") String empId){
		System.out.println(empId);
		ModelAndView model = new ModelAndView("success");
		model.addObject("empid", empId);
		return model;
	}

}
