package com.cg.appl.dao;

import com.cg.appl.dto.Emp;
import com.cg.appl.exceptions.EmpException;

public interface EmpDao {
	Emp getEmpDetails(int empno) throws EmpException;
}
