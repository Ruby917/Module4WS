package com.cg.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import com.cg.appl.dto.Emp;
import com.cg.appl.exceptions.EmpException;

//@Component("empDao")
//@Repository("empDao")
//@Scope("Singleton")
public class EmpDaoImpl implements EmpDao{
	private DataSource datasource;
	
	public EmpDaoImpl(){
		System.out.println("in constructor of EmpDaoImpl()");
	}

	@Resource(name="dataSource")
	public void setDatasource(DataSource datasource) {
		this.datasource = datasource;
	}

	@Override
	public Emp getEmpDetails(int empno) throws EmpException {
		System.out.println("in getEmpDetails()");
		Connection connect = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String qry = "SELECT EMPNO, ENAME, SAL FROM EMP WHERE EMPNO=?";
		try {
			connect = datasource.getConnection();
			pstmt = connect.prepareStatement(qry);
			pstmt.setInt(1, empno);
			rs = pstmt.executeQuery();
			if(rs.next()){
				Emp emp = new Emp();
				emp.setEmpNo(rs.getInt("EMPNO"));
				emp.setEmpNm(rs.getString("ENAME"));
				emp.setEmpSal(rs.getFloat("SAL"));
				return emp;
			}
		} catch (SQLException e) {
			throw new EmpException("problem in db handling",e);
		}finally{
			try {
				if(rs!=null){
					rs.close();
				}if(pstmt!=null){
					pstmt.close();
				}if(connect!=null){
					connect.close();
				}
			} catch (SQLException e) {
				throw new EmpException("problem in db closing",e);
			}
		}
		return null;
	}
	
}













