package com.cg.appl.service;

import com.cg.appl.dto.Emp;
import com.cg.appl.exceptions.EmpException;

public interface IEmpService {
	Emp getEmpDetails(int empno) throws EmpException;
}
