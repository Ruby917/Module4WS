package com.cg.appl.dao;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.cg.appl.util.DbUtil;

@Repository("entitydao")
public class EntityDao {
	private DbUtil dbUtil;
	
	public EntityDao() {
		System.out.println("in construct of entityDao");
	}

	@PostConstruct
	public void setUp(){
		System.out.println("in setUp of dao");
	}
	
	@PreDestroy
	public void cleanUp(){
		System.out.println("in cleanUp of dao");
	}
	//@Autowired
	//@Qualifier("dbUtil2")
	@Resource(name="dbUtil")
	public void setDbUtil1(DbUtil dbUtil){
		System.out.println("in setter of entity dao");
		this.dbUtil = dbUtil;
	}
	
	public void getConnection(){
		dbUtil.getConnection();
	}
}
