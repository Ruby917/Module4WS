create table trainee(
	traineeid number(4) primary key,
	traineename varchar2(15),
	traineeDomain varchar2(10),
	traineelocation varchar2(10));
	
insert into trainee(traineeid,traineename,traineeDomain,traineelocation) values(1000,'aaaa','Java','Pune');

insert into trainee(traineeid,traineename,traineeDomain,traineelocation) values(1001,'ruby','Asp .Net','Mumbai');

select * from trainee;

create sequence trainee_seq
start with 1;