package com.cg.appl.service;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.cg.appl.dao.ITraineeDao;
import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

//@Transactional
@Service("traineeService")
public class TraineeServiceImpl implements ITraineeService{

	private ITraineeDao trDao;
	
	@Resource(name="traineeDao")
	public void setTraineeDao(ITraineeDao trDao){
		this.trDao = trDao;
	}

	@Override
	public Trainee getTraineeDetails(int trId) throws TraineeException {
		return trDao.getTraineeDetails(trId);
	}

	@Override
	public List<Trainee> getAllTrainee() throws TraineeException {
		return trDao.getAllTrainee();
	}
	
	@Override
	public Trainee addTrainee(Trainee tr) throws TraineeException {
		return trDao.addTrainee(tr);
	}

}
