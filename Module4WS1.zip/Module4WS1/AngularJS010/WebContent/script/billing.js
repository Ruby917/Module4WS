var billModule = angular.module("billModule", []);

var billController = billModule.controller("billController",
		function($scope){
				$scope.billItem = {
						'qty' : 1,
						'cost' : 1,
						'discount' : 0
				};
				
				$scope.calBill = function() {
					return $scope.billItem.qty * $scope.billItem.cost;
				};
				
				$scope.calDiscount = function() {
					return ($scope.billItem.discount===0)?0:$scope.calBill() / $scope.billItem.discount;
				};
				
				$scope.calTotalBill = function() {
					return $scope.calBill() - $scope.calDiscount();
				};
		}
);