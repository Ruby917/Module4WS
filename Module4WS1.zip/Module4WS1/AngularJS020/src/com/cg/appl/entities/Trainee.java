package com.cg.appl.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;

@Entity(name="trainee")
@Table(name="TRAINEE")

@SequenceGenerator(name="trainee_generate", sequenceName="TRAINEE_SEQ", allocationSize=1, initialValue=1)
public class Trainee {
	
	@Id
	@Column(name="TRAINEEID")
	@GeneratedValue(generator="trainee_generate", strategy=GenerationType.SEQUENCE)
	private int traineeId;
	
	@NotEmpty(message="Name is Required")
	@Size(min=1,max=10, message="Name must be of size 1 to 10")
	@Column(name="TRAINEENAME")
	private String traineeName;
	
	@Column(name="TRAINEEDOMAIN")
	private String traineeDomain;
	
	@Column(name="TRAINEELOCATION")
	private String traineeLocation;
	
	public Trainee() {

	}

	public int getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}

	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}
}
