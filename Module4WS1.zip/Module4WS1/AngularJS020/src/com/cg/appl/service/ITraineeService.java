package com.cg.appl.service;

import java.util.List;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

public interface ITraineeService {
	Trainee getTraineeDetails(int trId) throws TraineeException;
	List<Trainee> getAllTrainee() throws TraineeException;
	Trainee addTrainee(Trainee tr) throws TraineeException;
}
