package com.cg.appl.controller;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;
import com.cg.appl.service.ITraineeService;


//http://localhost:8085/Spring130MvcEmp/welcome.do
@Controller
public class TraineeController {
	
	private ITraineeService trService;
	private List<String> domainList;
	private List<String> locationList;
	
	@PostConstruct
	public void initialize(){
		domainList = new ArrayList<>();
		domainList.add("Java");
		domainList.add("DotNet");
		domainList.add("Database");
		domainList.add("Analytics");
		
		locationList = new ArrayList<>();
		locationList.add("Pune");
		locationList.add("Mumbai");
		locationList.add("Bangalore");
		locationList.add("Kolkata");
		locationList.add("Delhi");
	}
	
	@Resource(name="traineeService")
	public void settraineeService(ITraineeService trService){
		this.trService= trService;
	}
	
	@RequestMapping("welcome")
	public ModelAndView getWelcomePage(){
		ModelAndView model = new ModelAndView("welcome");
		return model;
	}
	
	@RequestMapping("enterTraineeNo")
	public ModelAndView enterTraineeNo(){
		ModelAndView model = new ModelAndView("enterTraineeNo");
		return model;
	}
	
	@RequestMapping("getTraineeDetails")
	public ModelAndView showTraineeId(@RequestParam int trNo){
		ModelAndView model = null;
		try {
			System.out.println(trNo);
			Trainee trainee = trService.getTraineeDetails(trNo);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails", trainee);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("msg", e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("listAllTrainees")
	public ModelAndView listAllTrainees(){
		ModelAndView model = null;
		try {
			List<Trainee> trainees = trService.getAllTrainee();
			model = new ModelAndView("listAllTrainees");
			model.addObject("trainees", trainees);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("msg", e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("enterTrainee")
	public ModelAndView enterTrainee(){
		ModelAndView model = new ModelAndView("enterTrainee");
		model.addObject("trainee", new Trainee());
		model.addObject("domains", domainList);
		model.addObject("locations", locationList);
		return model;
	}
	
	@RequestMapping("addTrainee")
	public ModelAndView successAdd(@ModelAttribute @Valid Trainee tr,BindingResult result){
		ModelAndView model = new ModelAndView();
		if(result.hasErrors()){
			model.addObject("trainee", new Trainee());
			model.addObject("domains", domainList);
			model.addObject("locations", locationList);
			model.setViewName("enterTrainee");
			return model;
		}
		try {
			Trainee traineeResponse = trService.addTrainee(tr);
			model.setViewName("successInsert");
			model.addObject("trainee", traineeResponse);
		} catch (TraineeException e) {
			model.setViewName("error");
			model.addObject("msg", "Record Insertion Failed:"+e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("updateTrainee")
	public ModelAndView UpdateTrainee(@RequestParam("id") int trNo){
		System.out.println("in controlling method:"+trNo);
		ModelAndView model = null;
		model = new ModelAndView("error");
		model.addObject("msg", "dummy message");
		/*try {
			System.out.println(trNo);
			Trainee trainee = trService.getTraineeDetails(trNo);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails", trainee);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("msg", e.getMessage());
		}*/
		return model;
	}
	

}
