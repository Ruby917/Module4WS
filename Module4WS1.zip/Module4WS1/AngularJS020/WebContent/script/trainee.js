var trModule = angular.module("trModule", []);

var trController = trModule.controller("trController",
		function($scope){
				$scope.trainees = [
							{
								'traineeId'       : 'A001',
								'traineeName'     : 'Ruby',
								'traineeDomain'   : 'Java',
								'traineeLocation' : 'Mumbai' 
							},
							{
								'traineeId' 	  : 'A002',
								'traineeName'     : 'Riya',
								'traineeDomain'   : '.Net',
								'traineeLocation' : 'Pune' 
						    },
						    {
								'traineeId'       : 'A003',
								'traineeName'     : 'Anita',
								'traineeDomain'   : 'Python',
								'traineeLocation' : 'Bangalore' 
						    }
			];
			
				
		}
);

trModule.controller("traineeController",
					function($scope){
							$scope.trainee = {
									'traineeName' : 'Name Plaese',
									'domain' : "",
									'location' : ""
							};
							
							$scope.domains = [
									'Java','DotNet','Python','Scala'
							];
							
							$scope.locations = [
									'Mumbai','Pune','Bangalore','Kolkata','Chennai','Gurugram'
							];
});
















