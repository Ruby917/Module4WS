package com.cg.appl.commons;

public class CompanyDetails {
	
	private String companyName;
	private String companyMotto;
	private int niftyRank;
	
	private Address addr;

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyMotto() {
		return companyMotto;
	}

	public void setCompanyMotto(String companyMotto) {
		this.companyMotto = companyMotto;
	}

	public int getNiftyRank() {
		return niftyRank;
	}

	public void setNiftyRank(int niftyRank) {
		this.niftyRank = niftyRank;
	}

	public Address getAddr() {
		return addr;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}

	@Override
	public String toString() {
		return "CompanyDetails [companyName=" + companyName + ", companyMotto="
				+ companyMotto + ", niftyRank=" + niftyRank + ", addr=" + addr
				+ "]";
	}


}
