package com.cg.appl.dto;


import java.io.Serializable;

/*import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;*/

/*@Entity(name = "EMPLOYEE") // ALIES OF CLASS NAME
@Table(name = "EMP") //TABLE NAME

@NamedQueries({
	@NamedQuery(name="qryEmpsOnsal", query="SELECT E FROM EMPLOYEE E WHERE EMPSAL BETWEEN :FROM AND :TO"),
	@NamedQuery(name="getEmpList", query="select e from EMPLOYEE e"),
	@NamedQuery(name="qryEmpsComm", query="select e from EMPLOYEE e where comm>0")
})

@SequenceGenerator(name="emp_generate", sequenceName="EMP_SEQ", allocationSize=1, initialValue=1)*/
  
public class Emp implements Serializable{
	private int empNo;
	private String empNm;
	private Float empSal;
	private Float comm; 
	private Float totalsal;
	
	/*@Id
	@GeneratedValue(generator="emp_generate", strategy=GenerationType.SEQUENCE)*/
	public int getEmpNo() {  //empNo
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	
	//@Column(name="ENAME")
	public String getEmpNm() {   //empNm
		return empNm;
	}
	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}
	
	//@Column(name="SAL")
	public Float getEmpSal() {          //empSal
		return empSal;
	}
	public void setEmpSal(Float empSal) {
		this.empSal = empSal;
	}
	
	public Float getComm() {
		return comm;
	}
	public void setComm(Float comm) {
		this.comm = comm;
	}
	
	//@Column(name="empsal+comm")
	//@Transient
	public Float getTotalsal() {
		return getEmpSal()+(getComm()==null?0:getComm());
	}
	/*public void setTotalsal(Float totalsal) {
		this.totalsal = totalsal;
	}*/
	
	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", empSal="
				+ empSal + ", comm=" + comm + ", totalsal=" + getTotalsal() + "]";
	}
	
}
