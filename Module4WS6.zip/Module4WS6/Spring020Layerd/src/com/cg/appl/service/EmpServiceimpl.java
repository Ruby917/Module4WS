package com.cg.appl.service;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.appl.dao.EmpDao;
import com.cg.appl.dto.Emp;
import com.cg.appl.exceptions.EmpException;

//@Component("empservice")
@Service("empservice")
public class EmpServiceimpl implements IEmpService{
	private EmpDao edao;
	
	public EmpServiceimpl() {
		System.out.println("in constructor of EmpServiceImpl()");
	}

	@Resource(name="empDao")
	public void setEdao(EmpDao edao) {
		System.out.println("in service");
		this.edao = edao;
	}

	@Override
	public Emp getEmpDetails() throws EmpException {
		edao.getEmpDetails();
		return null;
	}

}
