package com.cg.appl.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.appl.dto.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.util.EntityManageUtil;

/* Component: for every class
 * Service: for service classes
 * Repository: for dao classes
 * Controller: for controller classes of spring MVC.
 * RestController: to declare controller classes for publishing REST services
 */


//@Component("empDao")
@Repository("empDao")
@Scope("Singleton")
public class EmpDaoImpl implements EmpDao{
	private EntityManageUtil util;
	
	public EmpDaoImpl(){
		System.out.println("in constructor of EmpDaoImpl()");
	}

	@Autowired   //Autowiring by type.
	@Qualifier("dbUtil") //Autowiring by name
	public void setUtil(EntityManageUtil util) {
		this.util = util;
	}

	@Override
	public Emp getEmpDetails() throws EmpException {
		System.out.println("in getEmpDetails()");
		return null;
	}
	
}













