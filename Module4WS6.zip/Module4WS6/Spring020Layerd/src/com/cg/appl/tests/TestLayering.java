package com.cg.appl.tests;

import org.springframework.context.ApplicationContext;

import com.cg.appl.exceptions.EmpException;
import com.cg.appl.service.IEmpService;
import com.cg.appl.util.SpringUtil;


public class TestLayering {
	public static void main(String[] args) {
		SpringUtil util = new SpringUtil();
		ApplicationContext ctx = util.getSpringContext();
		IEmpService service = ctx.getBean("empservice",IEmpService.class);
		
		try {
			service.getEmpDetails();
		} catch (EmpException e) {
			e.printStackTrace();
		}
		
	}

}
