package com.cg.appl.commons;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class CompanyDetails {
	
	private String companyName;
	private String companyMotto;
	private int niftyRank;
	private Address addr;
	private List<String> directors;
	private Set<String> branches;
	private Map<String, String> branchAddr; 
	private Properties ipAddresses;
	
	/*
	public CompanyDetails() {
		System.out.println("in company details  constructor");
	}*/
	
	public CompanyDetails(int niftyRank, String companyMotto) {
		System.out.println("in arg constructor for int,string");
		this.niftyRank = niftyRank;
		this.companyMotto = companyMotto;
	}
	
	public CompanyDetails(int niftyRank, String companyMotto,Address addr) {
		System.out.println("in arg constructor for int,string,addr");
		this.niftyRank = niftyRank;
		this.companyMotto = companyMotto;
		this.addr = addr;
	}

	public CompanyDetails(String companyMotto) {
		System.out.println("in args constructor for string");
		this.companyMotto = companyMotto;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyMotto() {
		return companyMotto;
	}

	public void setCompanyMotto(String companyMotto) {
		this.companyMotto = companyMotto;
	}

	public int getNiftyRank() {
		return niftyRank;
	}

	public void setNiftyRank(int niftyRank) {
		this.niftyRank = niftyRank;
	}

	public Address getAddr() {
		return addr;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}

	public List<String> getDirectors() {
		return directors;
	}

	public void setDirectors(List<String> directors) {
		this.directors = directors;
	}

	public Set<String> getBranches() {
		return branches;
	}

	public void setBranches(Set<String> branches) {
		this.branches = branches;
	}

	
	public Map<String, String> getBranchAddr() {
		return branchAddr;
	}

	public void setBranchAddr(Map<String, String> branchAddr) {
		this.branchAddr = branchAddr;
	}

	
	public Properties getIpAddresses() {
		return ipAddresses;
	}

	public void setIpAddresses(Properties ipAddresses) {
		this.ipAddresses = ipAddresses;
	}

	@Override
	public String toString() {
		return "CompanyDetails [companyName=" + companyName + ", companyMotto="
				+ companyMotto + ", niftyRank=" + niftyRank + ", addr=" + addr
				+ ", \n directors=" + directors + ", \n branches=" + branches
				+ ", \n branchAddr=" + branchAddr + ", \n ipAddresses=" + ipAddresses
				+ "]";
	}
}
