package com.cg.appl.dao;

import com.cg.appl.util.DbUtil;

public class EntityDao {
	private DbUtil dbUtil;
	
	public EntityDao() {
		System.out.println("in construct of entityDao");
	}

	
	public void setDbUtil2(DbUtil dbUtil){
		System.out.println("in setter of entity dao");
		this.dbUtil = dbUtil;
	}
	
	public void getConnection(){
		dbUtil.getConnection();
	}
}
