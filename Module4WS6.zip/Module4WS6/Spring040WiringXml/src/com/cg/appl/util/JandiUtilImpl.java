package com.cg.appl.util;

import java.sql.Connection;

public class JandiUtilImpl implements DbUtil{

	public JandiUtilImpl() {
		System.out.println("in constructor of jndi util");
	}
	
	@Override
	public Connection getConnection() {
		System.out.println("in get connection of jndi util");
		return null;
	}

}
