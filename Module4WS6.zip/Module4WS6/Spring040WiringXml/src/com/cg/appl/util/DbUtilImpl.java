package com.cg.appl.util;

import java.sql.Connection;

public class DbUtilImpl implements DbUtil{
	
	public DbUtilImpl() {
		System.out.println("in constructor of dbutil");
	}

	@Override
	public Connection getConnection() {
		System.out.println("In getConnection()");
		return null;
	}
}
