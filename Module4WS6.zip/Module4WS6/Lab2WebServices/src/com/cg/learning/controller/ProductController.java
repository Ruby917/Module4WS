package com.cg.learning.controller;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cg.learning.beans.Product;
import com.cg.learning.webservice.IProductService;
import com.cg.learning.webservice.ProductServiceImpl;

@Path("/products")
public class ProductController {
	IProductService pservice = null;

	public ProductController() {
		pservice = new ProductServiceImpl();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getProducts() {
		List<Product> listOfProducts = pservice.getAllProducts();
		return listOfProducts;
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Product addProduct(@FormParam("txtId") int txtId,
			@FormParam("txtName") String txtName,
			@FormParam("txtPrice") long txtPrice) {
		Product product = new Product();
		product.setProdId(txtId);
		product.setProdName(txtName);
		product.setProdPrice(txtPrice);
		return pservice.addProduct(product);
	}

}
