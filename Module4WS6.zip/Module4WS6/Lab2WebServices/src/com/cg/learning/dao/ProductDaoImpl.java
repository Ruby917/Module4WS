package com.cg.learning.dao;

import java.util.List;

import com.cg.learning.beans.Product;
import com.cg.learning.staticdb.ProductDB;

public class ProductDaoImpl implements IProductDao{
	List<Product> productList ;
	public ProductDaoImpl() {

	}

	@Override
	public List<Product> getAllProducts() {
		productList = ProductDB.loadList();
		return productList;
	}

	@Override
	public Product addProduct(Product product) {
		productList.add(product);
		return product;
	}
}
