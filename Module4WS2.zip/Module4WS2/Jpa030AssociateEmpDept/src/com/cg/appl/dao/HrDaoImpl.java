package com.cg.appl.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import com.cg.appl.dto.Dept;
import com.cg.appl.dto.Emp;
import com.cg.appl.exceptions.HrException;
import com.cg.appl.util.EntityManageUtil;

public class HrDaoImpl implements HrDao{
	private EntityManageUtil util;
	private EntityManager manager;
	
	public HrDaoImpl() throws HrException{
		util = new EntityManageUtil();
		manager = util.getManager();
	}

	public Emp getEmpDetails(int empNo) throws HrException {
		Emp emp = manager.find(Emp.class, empNo);
		if( emp == null){
			throw new HrException("wrong emp no.");
		}
		return emp;
	}
	
	@Override
	public Emp getEmpDetailsSafe(int empNo) throws HrException {
		Emp emp = manager.find(Emp.class, empNo);
		if( emp == null){
			throw new HrException("wrong emp no.");
		}
		manager.detach(emp);
		return emp;
	}
	
	@Override
	public List<Emp> getEmpList() throws HrException {
		List<Emp> emplist;
		try {
			TypedQuery<Emp> qry = manager.createNamedQuery("getEmpList",Emp.class);
			emplist = qry.getResultList();
		} catch (Exception e) {
			throw new HrException("Improper query fabrication",e);
		}
		return emplist;
	}
	
	@Override
	public List<Emp> getEmpOnSal(float from, float to) throws HrException {
		//String qrystr = "SELECT E FROM EMPLOYEE E WHERE EMPSAL BETWEEN :FROM AND :TO";
		TypedQuery<Emp> qry = manager.createNamedQuery("qryEmpsOnsal", Emp.class);
		qry.setParameter("FROM", from);
		qry.setParameter("TO", to);
		return qry.getResultList();
	}
	
	@Override
	public List<Emp> getEmpsForCommision() throws HrException {
		List<Emp> emplist;
		try {
			TypedQuery<Emp> qry = manager.createNamedQuery("qryEmpsComm",Emp.class);
			emplist = qry.getResultList();
		} catch (Exception e) {
			throw new HrException("Improper query fabrication",e);
		}
		return emplist;
	}


	@Override
	public Dept getDeptDetails(int deptid) throws HrException {
		Dept d = manager.find(Dept.class, deptid);
		if(d==null){
			throw new HrException("Dept not found");
		}
		return d;
	}
	
	@Override
	protected void finalize() throws Throwable {
		util.closeFactory();
		super.finalize();
	}

}













