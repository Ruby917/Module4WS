package com.cg.appl.dao;

import java.util.List;

import com.cg.appl.dto.Dept;
import com.cg.appl.dto.Emp;
import com.cg.appl.exceptions.HrException;

public interface HrDao {
	public Emp getEmpDetailsSafe(int empNo) throws HrException;
	List<Emp> getEmpList() throws HrException;
	List<Emp> getEmpOnSal(float fron,float to) throws HrException;
	List<Emp> getEmpsForCommision() throws HrException;
	Dept getDeptDetails(int deptid) throws HrException;
}
