package com.cg.appl.tests;

import com.cg.appl.dto.Dept;
import com.cg.appl.dto.Emp;
import com.cg.appl.exceptions.HrException;
import com.cg.appl.services.HrService;
import com.cg.appl.services.HrsericeImpl;

public class TestEmpQueries {

	public TestEmpQueries() {

	}

	public static void main(String[] args){
		try {
			HrService services = new HrsericeImpl();
			/*
			System.out.println("Employee list");
			List<Emp> emplist = services.getEmpList();
			for(Emp emp:emplist){
				System.out.println(emp);
			}*/
			
			Emp emp = services.getEmpDetails(7499);
			System.out.println(emp);
			//System.out.println(dept);
			
			System.out.println(emp.getDept().getDeptName());
			System.out.println("***********************");
			Dept dept = services.getDeptDetails(30);
			for(Emp e:dept.getEmps()){
				System.out.println(e);
			}
			System.out.println(dept);
		} catch (HrException e) {
			e.printStackTrace();
		}
	}

}
