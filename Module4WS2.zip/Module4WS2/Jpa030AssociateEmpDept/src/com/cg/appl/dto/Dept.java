package com.cg.appl.dto;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity(name="dept")
@Table(name="DEPARTMENT_MASTER")
public class Dept {
	
	@Id
	@Column(name="DEPT_CODE")
	private int deptid;
	
	@Column(name="DEPT_NAME")
	private String deptName;
	
	@OneToMany(mappedBy="dept")  //column name of ownership property in emp dto
	private List<Emp> emps;
	
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	public List<Emp> getEmps() {
		return emps;
	}
	@Override
	public String toString() {
		return "Dept [deptid=" + deptid + ", deptName=" + deptName + "]";
	}

}
