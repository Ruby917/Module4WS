package com.cg.appl.services;

import java.util.List;

import com.cg.appl.dao.HrDao;
import com.cg.appl.dao.HrDaoImpl;
import com.cg.appl.dto.Dept;
import com.cg.appl.dto.Emp;
import com.cg.appl.exceptions.HrException;

public class HrsericeImpl implements HrService{
	private HrDao empdao = null;

	public HrsericeImpl() throws HrException {
		empdao = new HrDaoImpl();
	}
	@Override
	public Emp getEmpDetails(int empNo) throws HrException {
		return empdao.getEmpDetailsSafe(empNo);
	}
	@Override
	public List<Emp> getEmpList() throws HrException {
		return empdao.getEmpList();
	}
	@Override
	public List<Emp> getEmpOnSal(float fron, float to) throws HrException {
		return empdao.getEmpOnSal(fron, to);
	}
	@Override
	public List<Emp> getEmpsForCommision() throws HrException {
		return empdao.getEmpsForCommision();
	}
	@Override
	public Dept getDeptDetails(int deptid) throws HrException {
		return empdao.getDeptDetails(deptid);
	}
}
