drop sequence emp_seq;

create sequence emp_seq 
start with 1
increment by 1;

select * from emp where comm>0;

alter table emp add comm number(5);

insert into emp values(emp_seq.nextVal,'Vandu',25000,300);

select * from emp;

delete from emp where empno=7600;