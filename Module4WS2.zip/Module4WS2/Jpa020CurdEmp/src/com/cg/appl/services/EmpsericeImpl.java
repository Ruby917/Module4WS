package com.cg.appl.services;

import java.util.List;

import com.cg.appl.dao.EmpDao;
import com.cg.appl.dao.EmpDaoImpl;
import com.cg.appl.dto.Emp;
import com.cg.appl.exceptions.EmpException;

public class EmpsericeImpl implements EmpService{
	private EmpDao empdao = null;

	public EmpsericeImpl() throws EmpException {
		empdao = new EmpDaoImpl();
	}
	@Override
	public Emp getEmpDetails(int empNo) throws EmpException {
		return empdao.getEmpDetailsSafe(empNo);
	}
	@Override
	public List<Emp> getEmpList() throws EmpException {
		return empdao.getEmpList();
	}
	@Override
	public Emp admitNewEmp(Emp emp) throws EmpException {
		return empdao.admitNewEmp(emp);
	}
	@Override
	public boolean updateName(int empNo, String newName) throws EmpException {
		return empdao.updateName(empNo, newName);
	}
	@Override
	public boolean updateEmp(Emp emp) throws EmpException {
		return empdao.updateEmp(emp);
	}
	@Override
	public boolean deleteEmp(int empNo) throws EmpException {
		return empdao.deleteEmp(empNo);
	}
	@Override
	public List<Emp> getEmpOnSal(float fron, float to) throws EmpException {
		return empdao.getEmpOnSal(fron, to);
	}
	@Override
	public List<Emp> getEmpsForCommision() throws EmpException {
		return empdao.getEmpsForCommision();
	}
}
