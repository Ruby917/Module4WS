package com.cg.appl.tests;

import java.util.List;

import com.cg.appl.dto.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpService;
import com.cg.appl.services.EmpsericeImpl;

public class TestEmpServices {
	
	public static void main(String[] args) {
		try {
			EmpService services = new EmpsericeImpl();
			/*Emp emp = services.getEmpDetails(7499);
			System.out.println(emp);
			
			System.out.println("Employee list");
			List<Emp> emplist = services.getEmpList();
			for(Emp e:emplist){
				System.out.println(e);
			}
			System.out.println("insertion of new employee");
			Emp em = new Emp();
			em.setEmpNo(1111);
			em.setEmpNm("Vandana");
			em.setEmpSal(50000f);
			
			services.admitNewEmp(em);
			System.out.println(services.getEmpDetails(1111));*/
			
			//services.updateName(1111, "bbbb");
			/*
			Emp emp = new Emp();
			emp.setEmpNo(1111);
			emp.setEmpNm("cccc");
			emp.setEmpSal(6000f);
			services.updateEmp(emp);*/
			
			services.deleteEmp(1111);
			System.out.println(services.getEmpDetails(1111));
		} catch (EmpException e) {

		}
	}

		
}










