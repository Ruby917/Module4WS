package com.cg.appl.tests;

import java.util.List;

import com.cg.appl.dto.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpService;
import com.cg.appl.services.EmpsericeImpl;

public class TestEmpQueries {

	public TestEmpQueries() {

	}

	public static void main(String[] args){
		try {
			EmpService services = new EmpsericeImpl();
			/*List<Emp> emplistOnSal = services.getEmpOnSal(2000, 3000);
			for(Emp emp:emplistOnSal){
				System.out.println(emp);
			}
			
			System.out.println("Employee list");
			List<Emp> emplist = services.getEmpList();
			for(Emp emp:emplist){
				System.out.println(emp);
			}*/
			
			/*Emp emp = new Emp();
			emp.setEmpNm("Shikha");
			emp.setEmpSal(30000f);
			
			emp = services.admitNewEmp(emp);
			System.out.println(emp);*/
			
			/*System.out.println("employee list on comm");
			List<Emp> emplist = services.getEmpsForCommision();
			for(Emp emp:emplist){
				System.out.println(emp);
			}*/
			
			System.out.println("Employee list");
			List<Emp> emplist = services.getEmpList();
			for(Emp emp:emplist){
				System.out.println(emp);
			}
		} catch (EmpException e) {
			e.printStackTrace();
		}
	}

}
