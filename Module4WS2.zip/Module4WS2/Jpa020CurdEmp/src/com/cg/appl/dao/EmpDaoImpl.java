package com.cg.appl.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import com.cg.appl.dto.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.util.EntityManageUtil;

public class EmpDaoImpl implements EmpDao{
	private EntityManageUtil util;
	private EntityManager manager;
	
	public EmpDaoImpl() throws EmpException{
		util = new EntityManageUtil();
		manager = util.getManager();
	}

	public Emp getEmpDetails(int empNo) throws EmpException {
		Emp emp = manager.find(Emp.class, empNo);
		if( emp == null){
			throw new EmpException("wrong emp no.");
		}
		return emp;
	}
	
	@Override
	public Emp getEmpDetailsSafe(int empNo) throws EmpException {
		Emp emp = manager.find(Emp.class, empNo);
		if( emp == null){
			throw new EmpException("wrong emp no.");
		}
		manager.detach(emp);
		return emp;
	}
	
	@Override
	public List<Emp> getEmpList() throws EmpException {
		List<Emp> emplist;
		try {
			TypedQuery<Emp> qry = manager.createNamedQuery("getEmpList",Emp.class);
			emplist = qry.getResultList();
		} catch (Exception e) {
			throw new EmpException("Improper query fabrication",e);
		}
		return emplist;
	}
	
	@Override
	public Emp admitNewEmp(Emp emp) throws EmpException {
		try {
			manager.getTransaction().begin();
			manager.persist(emp);
			manager.getTransaction().commit();
		} catch (RollbackException rl) {
			throw new EmpException("Employee duplicated",rl);
		}
		
		return emp;
	}
	
	@Override
	public boolean updateName(int empNo, String newName) throws EmpException {
		try {
			manager.getTransaction().begin();
			Emp emp = this.getEmpDetails(empNo);
			emp.setEmpNm(newName);
			manager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			throw new EmpException("failed name updation",e);
		}
	}

	@Override
	public boolean updateEmp(Emp emp) throws EmpException {
		try {
			manager.getTransaction().begin();
			
			manager.merge(emp);
			System.out.println("************");
			manager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			throw new EmpException("failed emp updation",e);
		}
	}
	
	@Override
	public boolean deleteEmp(int empNo) throws EmpException {
		try {
			manager.getTransaction().begin();
			Emp e = this.getEmpDetails(empNo);
			manager.remove(e);
			System.out.println("************");
			manager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			throw new EmpException("failed emp updation",e);
		}
		
	}
	
	@Override
	public List<Emp> getEmpOnSal(float from, float to) throws EmpException {
		//String qrystr = "SELECT E FROM EMPLOYEE E WHERE EMPSAL BETWEEN :FROM AND :TO";
		TypedQuery<Emp> qry = manager.createNamedQuery("qryEmpsOnsal", Emp.class);
		qry.setParameter("FROM", from);
		qry.setParameter("TO", to);
		return qry.getResultList();
	}
	
	@Override
	public List<Emp> getEmpsForCommision() throws EmpException {
		List<Emp> emplist;
		try {
			TypedQuery<Emp> qry = manager.createNamedQuery("qryEmpsComm",Emp.class);
			emplist = qry.getResultList();
		} catch (Exception e) {
			throw new EmpException("Improper query fabrication",e);
		}
		return emplist;
	}

	@Override
	protected void finalize() throws Throwable {
		util.closeFactory();
		super.finalize();
	}
}













