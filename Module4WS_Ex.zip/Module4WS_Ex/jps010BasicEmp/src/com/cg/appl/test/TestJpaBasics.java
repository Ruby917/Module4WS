package com.cg.appl.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.appl.dto.Emp;

public class TestJpaBasics {

	public static void main(String[] args) {
		//1. create entity manager factory. makes datasource, ConnectPool, Cache-2 ready.
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		
		//2. create entity manager. makes cache-1, dialect  ready.
		EntityManager manager = factory.createEntityManager();
		
		//3. Get a record
		Emp emp = manager.find(Emp.class, 7499);
		System.out.println(emp);
		
		Query qry = manager.createQuery("select e from EMPLOYEE e where empsal>=1500");  //Emp is dto class name
		List<Emp> emplist = qry.getResultList();
		for(Emp e:emplist){
			System.out.println(e);
		}
		
		//4. Close resources
		manager.close();
		factory.close();
		
	}

}
