package com.cg.appl.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "EMPLOYEE") // ALIES OF CLASS NAME
@Table(name = "EMP") //TABLE NAME
public class Emp implements Serializable{
	private int empNo;
	private String empNm;
	private Float empSal;
	
	@Id
	public int getEmpNo() {  //empNo
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	
	//@Column(name="ENAME")
	public String getEmpNm() {   //empNm
		return empNm;
	}
	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}
	
	//@Column(name="SAL")
	public Float getEmpSal() {          //empSal
		return empSal;
	}
	public void setEmpSal(Float empSal) {
		this.empSal = empSal;
	}
	
	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", empSal="
				+ empSal + "]";
	}
	
	
}
