import org.springframework.context.ApplicationContext;



public class TestEmployee {
	public static void main(String[] args) {
		SpringUtil util = new SpringUtil();
		ApplicationContext ctx = util.getSpringContext();
		SBU sbu = ctx.getBean("sbu",SBU.class);
		System.out.println("SBU Details");
		System.out.println("------------------------");
		System.out.println(sbu);
		//System.out.println(emp.getSbu());
	}

}
