package com.cg.appl.staticdb;

import java.util.ArrayList;
import java.util.List;

import com.cg.appl.dto.Employee;


public class Collection {
	
    static List<Employee> employeeList = loadList();
	
	public static List<Employee> loadList() {
		return employeeList;
	}
	
	static{
		if(employeeList==null){
			employeeList = new ArrayList<Employee>();
			employeeList.add(new Employee(100,"Ruby",10000.0f));
			employeeList.add(new Employee(101,"Saras",10500.0f));
			employeeList.add(new Employee(102,"Shikha",20000.0f));
			employeeList.add(new Employee(103,"Vandana",20500.0f));
			employeeList.add(new Employee(104,"Pooja",30000.0f));
			employeeList.add(new Employee(105,"Deepika",30500.0f));
			employeeList.add(new Employee(106,"Amruta",40000.0f));
			employeeList.add(new Employee(107,"Ruchi",40500.0f));
			employeeList.add(new Employee(108,"Jaini",50000.0f));
		}
	}

}
