package com.cg.appl.service;

import com.cg.appl.dto.Employee;
import com.cg.appl.exceptions.EmployeeException;


public interface IEmployeeService {
	public Employee getEmployeeDetails(int empId) throws EmployeeException;
}
