package com.cg.appl.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cg.appl.dao.EmployeeDao;
import com.cg.appl.dto.Employee;
import com.cg.appl.exceptions.EmployeeException;

@Service("empservice")
public class EmployeeServiceImpl implements IEmployeeService{
	private EmployeeDao edao;

	@Resource(name="empDao")
	public void setEdao(EmployeeDao edao) {
		this.edao = edao;
	}
	
	@Override
	public Employee getEmployeeDetails(int empId) throws EmployeeException {
		return edao.getEmployeeDetails(empId);
	}
	
}
