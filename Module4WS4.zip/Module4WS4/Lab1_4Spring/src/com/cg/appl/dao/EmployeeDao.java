package com.cg.appl.dao;

import java.util.List;

import com.cg.appl.dto.Employee;
import com.cg.appl.exceptions.EmployeeException;

public interface EmployeeDao {
	public Employee getEmployeeDetails(int empId) throws EmployeeException;
}
