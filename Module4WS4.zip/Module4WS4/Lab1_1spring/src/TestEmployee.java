import org.springframework.context.ApplicationContext;



public class TestEmployee {
	public static void main(String[] args) {
		SpringUtil util = new SpringUtil();
		ApplicationContext ctx = util.getSpringContext();
		Employee emp = ctx.getBean("emp",Employee.class);
		System.out.println("Employee Details");
		System.out.println("------------------------");
		System.out.println("Employee ID : "+emp.getEmployeeId());
		System.out.println("Employee Name : "+emp.getEmployeeName());
		System.out.println("Employee Salary : "+emp.getSalary());
		System.out.println("Employee BU : "+emp.getBusinessUnit());
		System.out.println("Employee Age : "+emp.getAge());

	}

}
