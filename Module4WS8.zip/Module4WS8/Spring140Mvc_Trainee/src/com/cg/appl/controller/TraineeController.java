package com.cg.appl.controller;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;
import com.cg.appl.service.ITraineeService;


//http://localhost:8085/Spring130MvcEmp/welcome.do
@Controller
public class TraineeController {
	
	private ITraineeService trService;
	
	@Resource(name="traineeService")
	public void settraineeService(ITraineeService trService){
		this.trService= trService;
	}
	
	@RequestMapping("enterTraineeNo")
	public ModelAndView enterTraineeNo(){
		ModelAndView model = new ModelAndView("enterTraineeNo");
		return model;
	}
	
	@RequestMapping("getTraineeDetails")
	public ModelAndView showEmpId(@RequestParam int trNo){
		ModelAndView model = null;
		try {
			System.out.println(trNo);
			Trainee trainee = trService.getTraineeDetails(trNo);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails", trainee);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("msg", e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("listAllTrainees")
	public ModelAndView listAllTrainees(){
		ModelAndView model = null;
		try {
			List<Trainee> trainees = trService.getAllTrainee();
			model = new ModelAndView("listAllTrainees");
			model.addObject("trainees", trainees);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("msg", e.getMessage());
		}
		return model;
	}

}
